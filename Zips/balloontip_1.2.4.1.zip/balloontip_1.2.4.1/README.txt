Balloon tip --- Quick readme


To start the demo application: Double-click balloontip-examples- ... .jar

To use balloon tips in your project: Use balloontip- ... .jar

For more information: Check doc/manual/index.htm